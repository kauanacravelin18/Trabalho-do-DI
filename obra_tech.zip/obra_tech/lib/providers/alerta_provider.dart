import 'package:flutter/material.dart';
import '../models/alerta.dart';
import '../services/database_service.dart';
import '../services/api_service.dart';

class AlertaProvider with ChangeNotifier {
  final db = DatabaseService.instance;
  List<Alerta> _alertas = [];

  List<Alerta> get alertas => _alertas;

  Future<void> carregarAlertas() async {
    // Tenta carregar da API
    final dados = await ApiService.instance.listarAlertas();
    if (dados.isNotEmpty) {
      _alertas = dados.map((e) => Alerta(
        mensagem: e['mensagem'],
        data: DateTime.parse(e['data']),
      )).toList();
      notifyListeners();
      return;
    }
    // Fallback local
    final data = await db.buscarAlertas();
    _alertas = data.map((e) => Alerta(
      mensagem: e['mensagem'],
      data: DateTime.parse(e['data']),
    )).toList();
    notifyListeners();
  }

  Future<void> adicionarAlerta(String mensagem) async {
    final agora = DateTime.now();
    // Salva na API
    await ApiService.instance.criarAlerta(mensagem);
    // Salva local
    await db.inserirAlerta({'mensagem': mensagem, 'data': agora.toIso8601String()});
    _alertas.insert(0, Alerta(mensagem: mensagem, data: agora));
    notifyListeners();
  }

  Future<void> limparAlertas() async {
    await ApiService.instance.limparAlertas();
    await db.limparAlertasDB();
    _alertas.clear();
    notifyListeners();
  }

  void verificarTemperatura(double temp) {
    if (temp > 36) {
      adicionarAlerta("🔥 Temperatura CRÍTICA!");
    } else if (temp > 30) {
      adicionarAlerta("⚠️ Temperatura ALTA");
    }
  }
}